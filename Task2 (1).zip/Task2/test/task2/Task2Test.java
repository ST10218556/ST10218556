/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ST10218556
 */
public class Task2Test {
    
    public Task2Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class Task2.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Task2.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of startApplication method, of class Task2.
     */
    @Test
    public void testStartApplication() {
        System.out.println("startApplication");
        Task2.startApplication();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkTaskDescription method, of class Task2.
     */
    @Test
    public void testCheckTaskDescription() {
        System.out.println("checkTaskDescription");
        String str = "";
        int len = 0;
        boolean expResult = false;
        boolean result = Task2.checkTaskDescription(str, len);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of createTaskID method, of class Task2.
     */
    @Test
    public void testCreateTaskID() {
        System.out.println("createTaskID");
        String expResult = "";
        String result = Task2.createTaskID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printTaskDetails method, of class Task2.
     */
    @Test
    public void testPrintTaskDetails() {
        System.out.println("printTaskDetails");
        String taskName = "";
        String taskDescription = "";
        String taskDeveloper = "";
        int duration = 0;
        String ID = "";
        String status = "";
        Task2.printTaskDetails(taskName, taskDescription, taskDeveloper, duration, ID, status);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
