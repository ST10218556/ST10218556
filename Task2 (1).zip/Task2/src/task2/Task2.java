/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task2;
import java.util.Random;
import javax.swing.JOptionPane;
/**
 *
 * ST10218556
 */
public class Task2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        JOptionPane.showMessageDialog(null,"Welcome to EasyKanbani");
        
        startApplication();
    }
    public static void startApplication(){
        
        String taskName = null;
        String taskDescription = null;
        String taskDeveloper = null;
        int duration = 0;
        String ID = createTaskID();
        String status  = null;
        
        int option = Integer.parseInt(JOptionPane.showInputDialog("Choose one of the following features from a numeric menu:\n" +
                    "1. Add tasks\n" +
                    "2. Show report\n" +
                    "3. Quit"));
        int taskNo;
        while(option!=3){
            if(option==1){
                taskNo = Integer.parseInt(JOptionPane.showInputDialog("Add Tasks Option Selected\n\n"
                        + "Please enter how many tasks you want to add"));
                for (int i = 0;i<taskNo; i++) {
                    taskName = JOptionPane.showInputDialog("Enter task name for task " + (i+1));
                    taskDescription = JOptionPane.showInputDialog("Enter task description for task " + (i+1));
                    
                    while(checkTaskDescription(taskDescription, 50)){
                         JOptionPane.showMessageDialog(null,"Please enter a task description of less than 50 characters");
                    }
                    JOptionPane.showMessageDialog(null,"Task successfully captured");
                    taskDeveloper = JOptionPane.showInputDialog("Enter the name of the developer for task " + (i+1));
                    duration = Integer.parseInt(JOptionPane.showInputDialog("Enter duration for task " + (i+1)));
                    
                    status = JOptionPane.showInputDialog("Enter the status of the task,for task " + (i+1)+ "\nTo Do\nDone\nDoing\n\n");
                    
                    printTaskDetails(taskName, taskDescription, taskDeveloper, duration,ID , status);
                }
                
            }
            else if(option==2){
                JOptionPane.showMessageDialog(null,"Coming Soon");
                break;
            }
        }
        JOptionPane.showMessageDialog(null,"Thank You");
    }
    public static boolean checkTaskDescription(String str, int len){
        
        return str.length()==len;
    }
    public static String createTaskID(){
         Random r = new Random();

            String RandNum = null;
            int id;
            for (int i = 1; i <= 4; i++)
            {
                id = r.nextInt(11);
                RandNum += id;
            }
            return RandNum;
    }
    public static void printTaskDetails(String taskName,String taskDescription,String taskDeveloper,int duration,String ID,String status){
        JOptionPane.showMessageDialog(null,"Task Name: " + taskName + "\nTask description: " + taskDescription + "\nDeveloper: " + taskDeveloper +
                "\nTask Duration: " + duration + "\nTask ID: " + ID + "\nTask Duration " + status);
    }
    
    
    
}
